// $Id$

/*
 Copyright (c) 2007-2015, Trustees of The Leland Stanford Junior University
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice, this 
 list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// ----------------------------------------------------------------------
//
//  File Name: flitchannel.cpp
//  Author: James Balfour, Rebecca Schultz
//
// ----------------------------------------------------------------------

#include "flitchannel.hpp"

#include <iostream>
#include <iomanip>

#include "router.hpp"
#include "globals.hpp"

// ----------------------------------------------------------------------
//  $Author: jbalfour $
//  $Date: 2007/06/27 23:10:17 $
//  $Id$
// ----------------------------------------------------------------------
FlitChannel::FlitChannel(Module * parent, string const & name, int classes)
: Channel<Flit>(parent, name), _routerSource(NULL), _routerSourcePort(-1), 
  _routerSink(NULL), _routerSinkPort(-1), _idle(0) {
	_active.resize(classes, 0);
}

/*
 * Comment by Febin
 * Sets the source for an inject channel and flit channel
 * For inject channel, source is not a router but a core, so _routerSource = NULL and _routerSourcePort is given as the router id(not the port number)
 */
void FlitChannel::SetSource(Router const * const router, int port) {
	_routerSource = router;
	_routerSourcePort = port;
}

/*
 * Comment by Febin
 * Sets the sink for an eject channel and flit channel
 * For eject channel, sink is not a router but a core, so _routerSink = NULL and _routerSinkPort is given as the router id(not the port number)
 */
void FlitChannel::SetSink(Router const * const router, int port) {
	_routerSink = router;
	_routerSinkPort = port;
}

void FlitChannel::Send(Flit * f) {
	if(f) {
		++_active[f->cl];
	} else {
		++_idle;
	}
	Channel<Flit>::Send(f);
}

void FlitChannel::ReadInputs() {
	Flit const * const & f = _input;
	if(f && f->watch) {
		// Modified by Febin starts
		*gWatchOut << GetSimTime() << " | " << FullName() << " | "
				<< "Febin : Beginning channel traversal" ;
		if(_routerSource!=NULL&&_routerSink!=NULL){
			*gWatchOut << " from "
					<< _routerSource->GetID() << ":"
					<< _routerSourcePort << " to "
					<< _routerSink->GetID() << ":"
					<< _routerSinkPort;
		}
		else if(_routerSource!=NULL){
			*gWatchOut << " from "
					<< _routerSource->GetID() << ":"
					<< _routerSourcePort << " to "
					<< _routerSinkPort;
		}
		else{
			*gWatchOut << " (injection) from "
					<< _routerSourcePort;
		}
		*gWatchOut << " for flit " << f->id
				<< " with delay " << _delay
				<< "." << endl;
		// Modified by Febin ends
	}
	Channel<Flit>::ReadInputs();
}

void FlitChannel::WriteOutputs() {
	Channel<Flit>::WriteOutputs();
	if(_output && _output->watch) {
		// Modified by Febin starts
		/**gWatchOut << GetSimTime() << " | " << FullName() << " | "
				<< "Completed channel traversal "
				<< " for flit " << _output->id
				<< "." << endl;*/
		*gWatchOut << GetSimTime() << " | " << FullName() << " | "
				<< "Febin : Completed channel traversal" ;
		if(_routerSource!=NULL&&_routerSink!=NULL){
			*gWatchOut << " from "
					<< _routerSource->GetID() << ":"
					<< _routerSourcePort << " to "
					<< _routerSink->GetID() << ":"
					<< _routerSinkPort;
		}
		else if(_routerSink!=NULL){
			*gWatchOut << " from "
					<< _routerSourcePort << " to "
					<< _routerSink->GetID() << ":"
					<< _routerSinkPort;
		}
		else{
			*gWatchOut << " (ejection) to "
					<< _routerSourcePort;
		}
		*gWatchOut << " for flit " << _output->id
				<< " with delay " << _delay
				<< "." << endl;
		// Modified by Febin ends
	}
}
